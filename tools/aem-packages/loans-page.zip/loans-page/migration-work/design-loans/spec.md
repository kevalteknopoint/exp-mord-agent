# Loans page — build spec (from design image)

Design reference: `migration-work/design-loans/design-full.jpg` (83x774 px mobile export — very low resolution) and 6x upscaled
slices `u-00.png` … `u-03.png` (498x1200 each, top to bottom). Mobile-first design; desktop must be derived sensibly.

Page: top-level path `/loans` (Content Sync only lists top-level pages). Page metadata: Title "Loans", Template "loans"
(adds `body.loans`, used to scope this page's styling so the site-wide Tata AIA styling of other pages is untouched).

## Sections (top to bottom)

### 1. Loan banners — 4 stacked full-width rounded cards (~24px radius, ~8px gap between cards, each ~ 1.9:1 tall on mobile ≈ 390x740)
Each card: centered text at the top (small uppercase letter-spaced eyebrow, large light-weight heading ~32px mobile, white pill "Apply now" button with dark text),
full-bleed photo filling the card (text sits over the top of it), and a tiny fine-print line at the bottom centre.
| # | Eyebrow | Heading | Text colour | Mood / background |
|---|---|---|---|---|
| 1 | VEHICLE LOAN (placeholder — illegible) | Hassle-Free vehicle loan in 4 easy steps | dark text (#1d2433-ish) on light | pale sky-blue gradient into a sunset band, dark car front-on at the bottom |
| 2 | CAR LOAN (placeholder — illegible) | One step closer to your favourite hatchback | white text | near-black/charcoal gradient, car silhouette with red light streaks |
| 3 | TWO-WHEELER LOAN | Riding with you, always | white text | black, red motorbike with light trails |
| 4 | LOAN AGAINST PROPERTY | More Savings on Loan Against Property | white text | warm sepia/brown sunset, person silhouette in a chair |
Fine print for each card (illegible → placeholder): "*T&C apply. Subject to eligibility and credit approval."
"Apply now" links: `#` (no real URLs known).

### 2. Testimonials (white background)
Small eyebrow "Testimonials", heading "Trusted by customers across India." (left-aligned, large light weight),
one visible quote card at a time (light grey #f2f2f2 rounded card, quote text ~14px, avatar circle + name + small role line),
prev/next circular outlined arrow buttons bottom right. Provide 3 placeholder testimonials:
text "[Placeholder testimonial — replace with a real customer quote.]", names "Customer name 1/2/3", role "Loan customer".

### 3. Customer service (white background)
Small eyebrow "Here to help" (placeholder — illegible), heading "Customer service" (left-aligned, large light weight),
stacked rounded light-grey rows (~16px radius), each: label left + black circular arrow button right; the FIRST row is tall and shows a
red/pink abstract graphic (stacked translucent red triangles/folds) filling its lower part. Rows: "Service Request Form" (with graphic),
"Download Forms", "Contact Us" (placeholder — 3rd row is cut off). Links `#`.

## Placeholder images
No usable photos exist (the export is 83 px wide). Generate clearly-placeholder images (e.g. ImageMagick gradients in each card's mood,
≥1200px wide, JPEG/WebP, small file size) and keep them in the code repo under `images/loans/` — they must be replaced by real photos later.
