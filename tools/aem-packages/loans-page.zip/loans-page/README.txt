Loans page - blocks and assets
================================

Page: /loans (built from a design image), theme "loans" (page metadata template = loans).
Uses the site's default header and footer (/nav, /footer).

blocks/                       3 blocks: cards-loan-banner, carousel-quote, cards-service-links
                              (js, css, Universal Editor model _<block>.json, metadata, README).
                              All import moveInstrumentation from scripts/scripts.js.
styles/loans.css              Page theme, scoped to body.loans. Add to styles/styles.css:
                                @import url('loans.css');
styles/fonts.css, fonts/      Inter font used by the theme.
images/loans/                 8 page images (referenced as /images/loans/...).
content/loans.plain.html      Page content.
tools/importer/               Import script + bundle, parsers, sections transformer.
migration-work/design-loans/  Semantic source HTML and design spec.

To use in another xwalk project:
 1. Copy the folders into the project root.
 2. Add the three block ids to the section filter (models/_section.json) and run
    npm run build:json to rebuild component-models/definition/filters.json.
 3. Add the loans.css import to styles/styles.css.
